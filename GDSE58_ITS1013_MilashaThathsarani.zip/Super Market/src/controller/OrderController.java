package controller;

import db.DbConnection;
import model.Orders;
import model.itemDetail;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderController {

    public boolean placeOrder(Orders order) {
        Connection con = null;
        try {
            con = DbConnection.getInstance().getConnection();
            PreparedStatement stm = con.
                    prepareStatement("INSERT INTO `Orders` VALUES(?,?,?)");

            stm.setObject(1, order.getOrderId());
            stm.setObject(2, order.getcId());
            stm.setObject(3, order.getOrderDate());

            return stm.executeUpdate() > 0;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
   private boolean saveOrderDetail(String ordersId, ArrayList<itemDetail> items) throws SQLException, ClassNotFoundException {
        for (itemDetail temp : items
        ) {
            PreparedStatement stm = DbConnection.getInstance().
                    getConnection().
                    prepareStatement("INSERT INTO `Order Detail` VALUES(?,?,?,?)");
            stm.setObject(1, temp.getItemCode());
            stm.setObject(2, ordersId);
            stm.setObject(3, temp.getQtyForSell());
            stm.setObject(4, temp.getUnitPrice());
            if (stm.executeUpdate() > 0) {

                if (updateQty(temp.getItemCode(), temp.getQtyForSell())){

                }else{
                    return false;
                }

            } else {
                return false;
            }
        }
        return true;
    }

   /* private boolean updateQty(String itemCode, int qty) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection()
                .prepareStatement
                        ("UPDATE ITEM SET qtyOnHand=(qtyOnHand-" + qty
                                + ") WHERE code='" + itemCode + "'");
        return stm.executeUpdate()>0;
    }*/
}

